export default class Book{
    constructor(id, name, genre, author){
        this.id=id;
        this.name=name;
        this.genre=genre;
        this.author=author;
    }
}

